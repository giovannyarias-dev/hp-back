"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.eEvents = void 0;
exports.eEvents = Object.freeze({
    LOGGED_IN: 'LOGGED_IN'
});
