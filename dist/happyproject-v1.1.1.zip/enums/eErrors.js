"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.eErrors = void 0;
exports.eErrors = Object.freeze({
    DB_ERROR: 'DB_ERROR'
});
