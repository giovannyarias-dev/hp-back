"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const user_1 = __importDefault(require("./user"));
class UserList {
    constructor() {
        this._users = [
            new user_1.default('Carlos', 'carlos.jpg', 'carlos.pabon@avaldigitallabs.com', 'team'),
            new user_1.default('Diana', 'diana.jpg', 'diana.hernandez@avaldigitallabs.com', 'po'),
            new user_1.default('Diego', 'diego.jpg', 'diego.grajales@avaldigitallabs.com', 'team'),
            new user_1.default('Gio', 'gio.jpg', 'cesarg.arias@avaldigitallabs.com', 'team'),
            new user_1.default('Jesús', 'jesus.png', 'jesus.rincon@avaldigitallabs.com', 'team'),
            new user_1.default('Joana', 'joana.jpg', 'joana.garcia@avaldigitallabs.com', 'team'),
            new user_1.default('Leidy', 'leidy.jpg', 'leidy.sanabria@avaldigitallabs.com', 'team'),
            new user_1.default('Lucho', 'lucho.jpg', 'luis.castellanos@avaldigitallabs.com', 'team'),
            new user_1.default('Freddy', 'freddy.jpg', 'freddy.bohorquez@avaldigitallabs.com', 'scrum'),
            new user_1.default('GioGlab', 'gio.jpg', 'giovannyarias.glab@gmail.com', 'scrum')
        ];
        this._usersOnPlanning = new Array();
    }
    addUser(email) {
        if (!this._usersOnPlanning.some(user => user.email === email)
            && this._users.some(user => user.email === email)) {
            const newUser = this._users.filter(user => user.email === email)[0];
            this._usersOnPlanning.push(newUser);
        }
        return this._usersOnPlanning;
    }
    setEffort(email, effort) {
        this._usersOnPlanning = this._usersOnPlanning.map((user) => {
            if (user.email === email) {
                user.effort = effort;
            }
            return user;
        });
        return this._usersOnPlanning;
    }
    cleanEffort() {
        this._usersOnPlanning = this._usersOnPlanning.map((user) => {
            user.effort = null;
            return user;
        });
    }
    get users() {
        return this._users;
    }
    get usersOnPlanning() {
        return this._usersOnPlanning;
    }
}
exports.default = UserList;
