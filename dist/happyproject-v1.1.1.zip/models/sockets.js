"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const user_list_1 = __importDefault(require("./user-list"));
class Sockets {
    constructor(io) {
        this.io = io;
        this.userList = new user_list_1.default();
        this.revealCards = false;
        this.socketEvents();
    }
    socketEvents() {
        this.io.on('connection', (socket) => {
            console.log('Connected Client');
            /*const data:any = { email: 'carlos.pabon@avaldigitallabs.com' };
            
            socket.on('login', (data) => {
              const userService = new UserService();
              const auditService = new AuditService();
              userService.login(data.email, 'name').then( user => {
                console.log('Respuesta login', user)
                auditService.saveEvent(user.id, eEvents.LOGGED_IN);
                this.userList.addUser(data.email);
                this.io.emit('current-users', this.userList.usersOnPlanning);
              }, err => {
                console.log('entra al error final');
              });
            });*/
            this.io.emit('current-users', this.userList.usersOnPlanning);
            if (this.revealCards) {
                socket.emit('reveal-cards', { reveal: true });
            }
            console.log('curret-users', this.userList.usersOnPlanning);
            socket.on('select-user', (data) => {
                this.userList.addUser(data.email);
                this.io.emit('current-users', this.userList.usersOnPlanning);
            });
            socket.on('set-effort', (data) => {
                this.userList.setEffort(data.email, data.effort);
                this.io.emit('current-users', this.userList.usersOnPlanning);
            });
            socket.on('clean-effort', (data) => {
                this.revealCards = false;
                this.userList.cleanEffort();
                this.io.emit('reveal-cards', { reveal: false });
                this.io.emit('current-users', this.userList.usersOnPlanning);
            });
            socket.on('reveal-cards', (data) => {
                this.revealCards = true;
                this.io.emit('reveal-cards', { reveal: true });
            });
        });
    }
}
module.exports = Sockets;
