"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var uuidv4 = require('uuid').v4;
var User = /** @class */ (function () {
    function User(name, image, role, email, effort) {
        this._id = uuidv4();
        this._name = name;
        this._image = image;
        this._invited = false;
        this._role = role;
        this._email = email;
        this._effort = effort;
    }
    Object.defineProperty(User.prototype, "email", {
        get: function () {
            return this._email;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(User.prototype, "effort", {
        set: function (effort) {
            this._effort = effort;
        },
        enumerable: false,
        configurable: true
    });
    return User;
}());
exports.default = User;
