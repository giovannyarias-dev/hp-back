"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var user_list_1 = __importDefault(require("./user-list"));
var Sockets = /** @class */ (function () {
    function Sockets(io) {
        this.io = io;
        this.userList = new user_list_1.default();
        this.revealCards = false;
        this.socketEvents();
    }
    Sockets.prototype.socketEvents = function () {
        var _this = this;
        this.io.on('connection', function (socket) {
            console.log('Connected Client');
            _this.io.emit('current-users', _this.userList.usersOnPlanning);
            if (_this.revealCards) {
                socket.emit('reveal-cards', { reveal: true });
            }
            console.log('curret-users', _this.userList.usersOnPlanning);
            socket.on('select-user', function (data) {
                _this.userList.addUser(data.email);
                _this.io.emit('current-users', _this.userList.usersOnPlanning);
            });
            socket.on('set-effort', function (data) {
                _this.userList.setEffort(data.email, data.effort);
                _this.io.emit('current-users', _this.userList.usersOnPlanning);
            });
            socket.on('clean-effort', function (data) {
                _this.revealCards = false;
                _this.userList.cleanEffort();
                _this.io.emit('reveal-cards', { reveal: false });
                _this.io.emit('current-users', _this.userList.usersOnPlanning);
            });
            socket.on('reveal-cards', function (data) {
                _this.revealCards = true;
                _this.io.emit('reveal-cards', { reveal: true });
            });
        });
    };
    return Sockets;
}());
module.exports = Sockets;
