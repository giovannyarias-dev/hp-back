"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var user_1 = __importDefault(require("./user"));
var UserList = /** @class */ (function () {
    function UserList() {
        this._users = [
            new user_1.default('Carlos', 'carlos.jpg', 'team', 'carlos.pabon@avaldigitallabs.com'),
            new user_1.default('Diana', 'diana.jpg', 'po', 'diana.hernandez@avaldigitallabs.com'),
            new user_1.default('Diego', 'diego.jpg', 'team', 'diego.grajales@avaldigitallabs.com'),
            new user_1.default('Gio', 'gio.jpg', 'team', 'cesarg.arias@avaldigitallabs.com'),
            new user_1.default('Jesús', 'jesus.png', 'team', 'jesus.rincon@avaldigitallabs.com'),
            new user_1.default('Joana', 'joana.jpg', 'team', 'joana.garcia@avaldigitallabs.com'),
            new user_1.default('Leidy', 'leidy.jpg', 'team', 'leidy.sanabria@avaldigitallabs.com'),
            new user_1.default('Lucho', 'lucho.jpg', 'team', 'luis.castellanos@avaldigitallabs.com'),
            new user_1.default('Freddy', 'freddy.jpg', 'scrum', 'freddy.bohorquez@avaldigitallabs.com'),
            new user_1.default('GioGlab', 'gio.jpg', 'scrum', 'giovannyarias.glab@gmail.com')
        ];
        this._usersOnPlanning = new Array();
    }
    UserList.prototype.addUser = function (email) {
        if (!this._usersOnPlanning.some(function (user) { return user.email === email; })
            && this._users.some(function (user) { return user.email === email; })) {
            var newUser = this._users.filter(function (user) { return user.email === email; })[0];
            this._usersOnPlanning.push(newUser);
        }
        return this._usersOnPlanning;
    };
    UserList.prototype.setEffort = function (email, effort) {
        this._usersOnPlanning = this._usersOnPlanning.map(function (user) {
            if (user.email === email) {
                user.effort = effort;
            }
            return user;
        });
        return this._usersOnPlanning;
    };
    UserList.prototype.cleanEffort = function () {
        this._usersOnPlanning = this._usersOnPlanning.map(function (user) {
            user.effort = null;
            return user;
        });
    };
    Object.defineProperty(UserList.prototype, "users", {
        get: function () {
            return this._users;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UserList.prototype, "usersOnPlanning", {
        get: function () {
            return this._usersOnPlanning;
        },
        enumerable: false,
        configurable: true
    });
    return UserList;
}());
exports.default = UserList;
