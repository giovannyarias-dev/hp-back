"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Servidor de Express
var express = require("express");
var http = require('http');
var socketio = require('socket.io');
var path = require('path');
var Sockets = require('./sockets');
var Server = /** @class */ (function () {
    function Server() {
        this.app = express();
        this.port = Number(process.env.PORT);
        this.server = http.createServer(this.app);
        this.io = socketio(this.server, {
            cors: {
                origin: "http://localhost:3000",
                //origin: "http://happyprojectapp.s3-website.us-east-2.amazonaws.com",
                methods: ["GET", "POST"]
            }
        });
    }
    Server.prototype.middlewares = function () {
        this.app.use(express.static(path.resolve(__dirname, '../public')));
    };
    Server.prototype.socketsConfiguration = function () {
        new Sockets(this.io);
    };
    Server.prototype.execute = function () {
        var _this = this;
        // Middlewares init
        this.middlewares();
        // Sockets init
        this.socketsConfiguration();
        // Server init
        this.server.listen(this.port, function () {
            console.log('Server running in port:', _this.port);
        });
    };
    return Server;
}());
module.exports = Server;
