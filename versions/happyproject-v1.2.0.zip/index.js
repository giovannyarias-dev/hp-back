"use strict";
var Server = require('./models/server');
require('dotenv').config();
var server = new Server();
server.execute();
