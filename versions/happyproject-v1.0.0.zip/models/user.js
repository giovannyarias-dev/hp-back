const { v4: uuidv4 } = require('uuid');

class User {

    constructor(name, image) {
        this.id = uuidv4();
        this.name = name;
        this.image = image;
        this.effort = null;
        this.invited = false;
    }

}

module.exports = User;
