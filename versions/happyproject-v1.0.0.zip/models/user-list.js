const User = require('./user');

class UserList {

    constructor() {
        this.users = [];
    }

    addUser(name) {

        if (this.users.filter(user => user.name === name).length === 0
            && this.isUserValid(name)) {
            const newUser = new User(name, 'avatar.png');
            this.users.push(newUser);
        }
        return this.users;
    }

    setEffort(name, effort) {
        this.users = this.users.map((user) => {
            if (user.name === name) {
                user.effort = effort;
            }
            return user;
        });
        return this.users;
    }

    cleanEffort() {
        this.users = this.users.map((user) => {
            user.effort = null;
            return user;
        })
    }

    getUsers() {
        return this.users;
    }

    isUserValid(name) {
        if (name === 'Carlos' ||
            name === 'Diana' ||
            name === 'Diego' ||
            name === 'Gio' ||
            name === 'Jesus' ||
            name === 'Jesus' ||
            name === 'Joana' ||
            name === 'Leidy' ||
            name === 'Lucho' ||
            name === 'Freddy'
        )
            return true;
        else
            return false;
    }



    /*    removeBand(id) {
            this.bands = this.bands.filter(band => band.id !== id);
        }
    
        getBands() {
            return this.bands;
        }
    
        increaseVotes(id) {
            this.bands = this.bands.map(band => {
    
                if (band.id === id) {
                    band.votes += 1;
                }
    
                return band;
    
            })
        }
    
        changeName(id, newName) {
            this.bands = this.bands.map(band => {
    
                if (band.id === id) {
                    band.name = newName;
                }
    
                return band;
    
            })
        }*/

}


module.exports = UserList;