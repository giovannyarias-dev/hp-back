const UserList = require('./user-list');

class Sockets {

    constructor(io) {

        this.io = io;
        this.userList = new UserList();

        this.socketEvents();
    }

    socketEvents() {

        this.io.on('connection', (socket) => {

            console.log('Connected Client');
            this.io.emit('current-users', this.userList.getUsers());

            socket.on('select-user', (data) => {
                this.userList.addUser(data.userName);
                this.io.emit('current-users', this.userList.getUsers());
            });

            socket.on('set-effort', (data) => {
                this.userList.setEffort(data.userName, data.effort);
                this.io.emit('current-users', this.userList.getUsers());
            });

            socket.on('clean-effort', (data) => {
                this.userList.cleanEffort();
                this.io.emit('reveal-cards', { reveal: false });
                this.io.emit('current-users', this.userList.getUsers());
            });

            socket.on('reveal-cards', (data) => {
                this.io.emit('reveal-cards', { reveal: true });
            });








            /* 
            // Emitir al cliente conectado, todas las bandas actuales
            socket.emit('current-bands', this.bandList.getBands());

            // votar por la banda
            socket.on('votar-banda', (id) => {
                this.bandList.increaseVotes(id);
                this.io.emit('current-bands', this.bandList.getBands());
            });

            // Borrar banda
            socket.on('borrar-banda', (id) => {
                this.bandList.removeBand(id);
                this.io.emit('current-bands', this.bandList.getBands());
            });

            // Cambiar nombre de la banda
            socket.on('cambiar-nombre-banda', ({ id, nombre }) => {
                this.bandList.changeName(id, nombre);
                this.io.emit('current-bands', this.bandList.getBands());
            });

            // Crear una nueva banda
            socket.on('crear-banda', ({ nombre }) => {
                this.bandList.addBand(nombre);
                this.io.emit('current-bands', this.bandList.getBands());
            });*/


        });
    }


}


module.exports = Sockets;